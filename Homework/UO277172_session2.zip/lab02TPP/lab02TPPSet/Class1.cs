﻿using System;

namespace lab02TPPSet
{
    public class Class1
    {

    }
}
