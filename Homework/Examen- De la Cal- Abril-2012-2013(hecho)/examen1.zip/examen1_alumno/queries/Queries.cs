﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TPP.Laboratory.tpplab_poo_pfunc
{
    
    class Query {

        private Modelo m = new Modelo();
       
        static void Main(string[] args) {
            Query query = new Query();
            
            try
            {
                query.Query1();
                query.Query2();
                query.Query3();
            }
            catch (Exception ex)
            {
                Console.WriteLine("error: {0}", ex.StackTrace);
            }            
        }

         // Ejercicio 1. 5 puntos
         // Mostrar la lista de equipos que tengan algun jugador español ("ESP") usando f. de orden superior propias. 
         private void Query1()
         {

         }
         // Ejercicio 2. 3 puntos.
         // Mostrar la lista de equipos que tengan algun jugador español ("ESP") usando linq. 
         private void Query2()
         {
       
         }
        
         // Ejercicio 3. 2 puntos
         // Mostrar el nombre, apellidos y puntuación del jugador con mas puntos (1p+2*2p+3*3p) en las 10 temporadas
         private void Query3()
         {
         

         }
       

    }
       
}
